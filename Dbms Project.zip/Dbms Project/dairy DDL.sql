

create table farmOwner
(
owner_id  numeric(4,0),
owner_name varchar(25),
address varchar(50),
contact varchar(20),
primary key (owner_id)
);

create table manager
(
m_id numeric(3,0),
name varchar(25),
email varchar(50),
phone varchar(20),
primary key (m_id)
);

create table Fowner_manager
(
owner_id numeric(4,0),
m_id numeric(3,0),
primary key (owner_id, m_id),
foreign key (owner_id) references farmOwner (owner_id),
foreign key (m_id) references manager (m_id)
);

create table customer
(
c_id numeric(4),
name varchar(25),
address varchar(50),
contact varchar(20),
primary key(c_id)
);


create table supplier
(
supp_id numeric(4),
name varchar(25),
cust_id numeric(4),
products_supplied numeric(5),
contact varchar(20),
primary key (supp_id),
foreign key (cust_id) references customer (c_id)
);

create table distributor
(
d_id numeric(3,0),
name varchar(20),
man_id numeric(3,0),
supplier_id numeric(4),
email varchar(50),
products_supplied numeric(5,0),
primary key(d_id),
foreign key (man_id) references manager (m_id),
foreign key (supplier_id) references supplier (supp_id)
);



create table milk_production
(
milk_id numeric(4),
cat_id numeric(4),
cattle_id numeric(3),
primary key(milk_id,cat_id)
);


create table manager_production
(
mlk_id numeric(4),
cat numeric(4),
id numeric(3,0),
primary key(mlk_id, cat, id)
);


create table financial_records
(
record_id numeric(3,0),
profit_loss varchar(20),
finyear numeric(4),
primary key(record_id)
);


create table manager_financialrecords
(
m_id numeric(3,0),
record_id numeric(3,0),
primary key (m_id, record_id),
foreign key (m_id) references manager (m_id),
foreign key (record_id) references financial_records (record_id)
);

create table cattle
(
cattle_id numeric(4),
cattle_count numeric(4),
cattle_type varchar(30),
primary key(cattle_id)
);

create table farm_cattle
(
owner_id numeric(4,0),
cattle_id numeric(4),
primary key(owner_id, cattle_id),
foreign key (owner_id) references farmOwner (owner_id),
foreign key (cattle_id) references cattle (cattle_id)
);

create table categories
(
category_id numeric(4),
category_name varchar(25),
cattle varchar(25),
cat_count numeric(4),
primary key (category_id)
);

create table cattle_categories
(
cattle_id numeric(4),
category_id numeric(4),
primary key(cattle_id, category_id),
foreign key (cattle_id) references cattle (cattle_id),
foreign key (category_id) references categories (category_id)
);

create table fodder
(
fo_id numeric(4),
type varchar(20),
qty_consumed numeric(8),
primary key(fo_id)
);

create table cattle_fodder
(
fo_id numeric(4),
cattle_id numeric(4),
primary key(fo_id, cattle_id),
foreign key (fo_id) references fodder (fo_id),
foreign key (cattle_id) references cattle (cattle_id)
);

create table products
(
prod_id varchar(50),
cust numeric(4),
mfg_dt varchar(50),
brand varchar(25),
quantity numeric(4),
exp_dt varchar(50),
fat_content numeric(5),
primary key(prod_id),
foreign key (cust) references customer (c_id)
);

create table distributor_products
(
dist_id numeric(3,0),
prod_dp_id varchar(50),
primary key(dist_id, prod_dp_id),
foreign key (dist_id) references distributor (d_id) ON DELETE CASCADE,
foreign key (prod_dp_id) references products (prod_id) 
);




create table products_supplier
(
prod_id varchar(50),
supp_id numeric(4),
primary key(prod_id, supp_id),
foreign key (prod_id) references products (prod_id),
foreign key (supp_id) references supplier (supp_id)
);




create table orders
(
order_id numeric(5),
quantity varchar(25),
price numeric(4),
discount numeric(4),
tax numeric(4),
primary key(order_id)
);


create table customer_order
(
c_id numeric(4),
order_id numeric(5),
primary key(c_id, order_id),
foreign key (c_id) references customer (c_id),
foreign key (order_id) references orders (order_id)
);

