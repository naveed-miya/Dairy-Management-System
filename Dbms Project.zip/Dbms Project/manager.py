from tkinter import *
import tkinter as tk
from tkinter import Label





def display():
    #dummy
    x="dummy"
# Create object
root = tk.Tk()
# Adjust size
root.geometry( "200x200" )
  
# Change the label text


def supp():
    display("supplier")
def dist():
    display("distributor")
def fin():
    display("financial_records")
def ord():
    display("orders")
def cus():
    display("customer_orders")

 

  
root.geometry("500x300")

label = Label( root , text = "Manager Dashboard" )
label.pack()

button1 = tk.Button(root, text ="Exit",
					bg ='blue', command =root.destroy)
button1.place(x = 150, y = 250, width = 55)

button2 = tk.Button(root, text ="Supplier",
					bg ='blue', command = supp)
button2.place(x = 80, y = 120, width = 70)

button3 = tk.Button(root, text ="Distributor",
					bg ='blue', command = dist)
button3.place(x = 150, y = 120, width = 100)

button4 = tk.Button(root, text ="Financial reports",
					bg ='blue', command = fin)
button4.place(x = 250, y = 120, width = 130)

button5 = tk.Button(root, text ="Orders",
					bg ='blue', command = ord)
button5.place(x = 150, y = 150, width = 130)

button6 = tk.Button(root, text ="Customer Orders",
					bg ='blue', command = cus)
button6.place(x = 250, y = 150, width = 130)

  
# Execute tkinter
root.mainloop()