from tkinter import *
import tkinter as tk
from tkinter import Label





# Create object
root = tk.Tk()

# Adjust size
root.geometry( "200x200" )
  
# Change the label text
def display():
    #dummy
    x="dummy"


def supp():
    display("supplier")
def disp():
    display("distributor_products")
def prod():
    display("products")
def dis():
    display("distributor")

  
root.geometry("500x300")

label = Label( root , text = "Distributer Dashboard" )
label.pack()

button1 = tk.Button(root, text ="distributor",
					bg ='blue', command = dis)
button1.place(x = 35, y = 120, width = 80)

button2 = tk.Button(root, text ="Supplier",
					bg ='blue', command = supp)
button2.place(x = 115, y = 120, width = 75)

button3 = tk.Button(root, text ="Products",
					bg ='blue', command = prod)
button3.place(x = 190, y = 120, width = 80)

button4 = tk.Button(root, text ="Distributor_products",
					bg ='blue', command = disp)
button4.place(x = 270, y = 120, width = 150)
# Create Label
button5 = tk.Button(root, text ="Exit",
					bg ='blue', command =root.destroy)
button5.place(x = 150, y = 250, width = 55)
  
# Execute tkinter
root.mainloop()