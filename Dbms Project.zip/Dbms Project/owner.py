from tkinter import *
import tkinter as tk
from tkinter import Label




# Create object
root = tk.Tk()

# Adjust size
root.geometry( "200x200" )
  
# Change the label text
def display():
    #dummy
    x="dummy"


def man():
    display("manager")
def cat():
    display("cattle")
def own():
    display("farmOwner")


  
root.geometry("500x300")

label = Label( root , text = "Farm Owner Dashboard" )
label.pack()

button1 = tk.Button(root, text ="Manager",
					bg ='blue', command = man)
button1.place(x = 185, y = 120, width = 80)

button2 = tk.Button(root, text ="Cattle",
					bg ='blue', command = cat)
button2.place(x = 295, y = 120, width = 75)

button3 = tk.Button(root, text ="owner",
					bg ='blue', command = own)
button3.place(x = 85, y = 120, width = 75)


# Create Label
button5 = tk.Button(root, text ="Exit",
					bg ='blue', command =root.destroy)
button5.place(x = 185, y = 240, width = 55)
  
# Execute tkinter
root.mainloop()