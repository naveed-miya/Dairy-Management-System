from tkinter import *
from tkinter import ttk
from tkinter import messagebox,simpledialog
import tkinter as tk
import mysql.connector
from tkinter import Label
from PIL import ImageTk, Image



#set path of the folder location to run all the functions

def manager():
    exec(open("/Users/laptopcheckout/Desktop/Dbms Project/manager.py").read())
    	
def distributor():
    	exec(open("/Users/laptopcheckout/Desktop/Dbms Project/distributor.py").read())
def supplier():
    	exec(open("/Users/laptopcheckout/Desktop/Dbms Project/supplier.py").read())
def owner():
    	exec(open("/Users/laptopcheckout/Desktop/Dbms Project/owner.py").read())

# Create an object of tkinter ImageTk. In this you have to give image path
img = Image.open("/Users/laptopcheckout/Desktop/Dbms Project/farm.jpg")



root = tk.Tk()
root.title("Dairy Products Order Page")
root.geometry("800x500")

def display(x):
    con1 = mysql.connector.connect(host ="localhost",
									user = "root",
									password = "",
									db ="dairy") 

    root1 = tk.Tk()

    root.title("Display table")
    tree = ttk.Treeview(root1, column=("c1", "c2", "c3", "c4","c5", "c6"))
    tree.pack()


    cur1 = con1.cursor()

    cur1.execute("SELECT * FROM "+x)

    rows = cur1.fetchall()

    field_names = [i[0] for i in cur1.description]  
    tree.insert("", tk.END, values=field_names) 

    for row in rows:
     #   print(row) 
        tree.insert("", tk.END, values=row) 
    
    backbtn = tk.Button(root1, text ="back",
					bg ='blue',command=root1.destroy).pack()

    con1.close()
   


def submitact1(u,p,e):
    	
	user = u
	passw =p

	# If password is enetered by the
	# user
	if passw:
		try:
			db = mysql.connector.connect(host ="localhost",
									user = user,
									password = passw,
									db ="dairy")
			cursor = db.cursor()
			manager()
		except:
			messagebox.showerror("showerror", "Login credentials are incorrect             			please try again")
	# If no password is enetered by the
	# user
	else:
		try:
			db = mysql.connector.connect(host ="localhost",
									user = user,
									db ="dairy")
			cursor = db.cursor()
			if e =='m':
				manager()
			elif e =='s':
				supplier()
			elif e =='d':
				distributor()
			else:
				owner()
		except:
			messagebox.showerror("showerror", "Login credentials are incorrect             			please try again")



def loginm():
    m='m'
    login(m)
def logins():
    s='s'
    login(s)
def logind():
    d='d'
    login(d)    
def logino():
    o='o'
    login(o)   
    


def login(w):
    root = tk.Tk()
    root.geometry("300x300")
    root.title("Dairy management Login Page")

    def submitact():
        user = Username.get()
        passw = password.get()
        root.destroy()
        submitact1(user, passw,w)
        

# Defining the first row
    lblfrstrow = tk.Label(root, text ="Username -", )
    lblfrstrow.place(x = 50, y = 20)

    Username = tk.Entry(root, width = 35)
    Username.place(x = 150, y = 20, width = 100)

    lblsecrow = tk.Label(root, text ="Password -")
    lblsecrow.place(x = 50, y = 50)

    password = tk.Entry(root, width = 35)
    password.place(x = 150, y = 50, width = 100)

    submitbtn = tk.Button(root, text ="Login",
					bg ='blue', command = submitact)
    submitbtn.place(x = 150, y = 105, width = 55)
    root.mainloop()


def newOrder():
	root1 = tk.Tk()

	

	def nn():
		s=clicked.get()
		newOrder1(s)

	def newOrder1(n):
		con1 = mysql.connector.connect(host ="localhost",
									user = "root",
									password = "",
									db ="dairy") 
		root = tk.Tk()
		root.title("Data Insertion")

		mycursor = con1.cursor()
		sql1="select max(order_id) from orders"
		mycursor.execute(sql1)
		a = mycursor.fetchone()
		b = float(a[0])
		c=b+1

		s=n

		if s == 'Amul':
			cost=28.0
		elif s == 'Heritage':
			cost=22.0
		elif s == 'Jersey':
			cost=28.0
		else :
			cost =18.0
    
		q= quantity.get()
		dis=5.0
		tax=5.0
 
		sql = "INSERT INTO orders (order_id, quantity, price, discount, tax) VALUES (%s,%s,%s,%s,%s)"
		val=(c,q,cost,dis,tax)
		mycursor.execute(sql,val)
		if q:
			try:
				id=Userid.get()
				sql1 = "INSERT INTO customer_order(c_id,order_id) values (%s,%s)"
				val1=(id,c)
				mycursor.execute(sql1,val1)
				con1.commit()
				con1.close()
				messagebox.showinfo("showinfo", "Order Placed Successfully")
			except:
				messagebox.showerror("showerror", "Please enter valid customer id or signup if new customer")


		else:
			messagebox.showerror("showerror", "Please enter quantity")
		root.destroy()

	root1.geometry("500x300")
	root1.title("Dairy Products Order Page")
# Create Dropdown menu
	options = [
    	"Hatsun",
    	"Heritage",
    	"Jersey",
    	"Amul",
        "Mother Dairy"
		]
# datatype of menu text
	clicked = tk.StringVar(root1)
  
# initial menu text
	clicked.set( "Amul" )

	drop = OptionMenu( root1 , clicked , *options )
	drop.place(x = 230, y = 70)
	# Defining the first row
	lblfrstrow2 = tk.Label(root1, text ="User Id -", )
	lblfrstrow2.place(x = 140, y = 20)
	Userid = tk.Entry(root1, width = 35)
	Userid.place(x = 210, y = 20, width = 100)

	lblfrstrow1 = tk.Label(root1, text ="Select the Milk Brand to order :", )
	lblfrstrow1.place(x = 30, y = 70)

	lblfrstrow3 = tk.Label(root1, text ="Quantity -", )
	lblfrstrow3.place(x = 140, y = 120)

	quantity = tk.Entry(root1, width = 10)
	quantity.place(x = 210, y = 120, width = 100)

	submitbtn = tk.Button(root1, text ="Place a order",
					bg ='blue', command=nn )
	submitbtn.place(x = 210, y = 160, width = 100)

	lblfrstrow = tk.Label(root1, text ="First time user? please signup here", )
	lblfrstrow.place(x = 20, y = 240)

	submitbtn1 = tk.Button(root1, text ="signup",
					bg ='blue', command=signup )
	submitbtn1.place(x = 240, y = 237, width = 100)

	button1 = tk.Button(root1, text ="Exit",
					bg ='blue', command =root1.destroy)
	button1.place(x = 150, y = 270, width = 55)

	root1.mainloop()


def signup():
    con1 = mysql.connector.connect(host ="localhost",
									user = "root",
									password = "",
									db ="dairy") 
    mycursor = con1.cursor()
    root = tk.Tk()
    root.title("New User Signup page")
    answer1 = simpledialog.askstring("Input", "Enter your name?",
                                parent=root)

    answer2 = simpledialog.askstring("Input", "Enter your Adress",
                                 parent=root)
                                 

    answer3 = simpledialog.askfloat("Input", "Enter your contact number",
                               parent=root)
    sql1="select max(c_id) from customer"
    mycursor.execute(sql1)
    a = mycursor.fetchone()
    b = int(a[0])
    c=b+1
    sql = "INSERT INTO customer (c_id, name, address,contact) VALUES (%s, %s, %s,%s)"
    root.geometry("300x300")
        
    if answer1 and answer2 and answer3:
        val=(c,answer1,answer2,answer3)
        mycursor.execute(sql, val)
        con1.commit()
        con1.close()
        messagebox.showinfo("showinfo", "Signup successfull and your user id is: "+str(c))
        root.destroy() 
    else:
        messagebox.showerror("showerror", "Entered details are invalid.. please try again.")
        root.destroy()





frame = Frame(root, width=100, height=200)
frame.pack()
frame.place(anchor='w', relx=0.005, rely=0.65)


resize_image = img.resize((800, 650),Image.Resampling.LANCZOS)

img = ImageTk.PhotoImage(resize_image)



# Create a Label Widget to display the text or Image
label = Label(frame, image = img)
label.pack()


submitbtn = tk.Button(root, text ="Place a order",
					bg ='blue', command=newOrder)
submitbtn.place(x = 200, y = 440, width = 100)

lblfrstrow2 = tk.Label(root, text ="Dairy Products Management System")
lblfrstrow2.place(x = 50, y = 20)
lblfrstrow2.config(font=('Helvatical bold',45))

button1 = tk.Button(root, text ="Distributor",
					bg ='blue', command =logind)
button1.place(x = 50, y = 380, width = 85)

button2 = tk.Button(root, text ="Exit",
					bg ='blue', command = root.destroy)
button2.place(x = 370, y = 440, width = 85)

button3 = tk.Button(root, text ="Supplier",
					bg ='blue', command = logins)
button3.place(x = 50, y = 410, width = 85)

button4 = tk.Button(root, text ="Farm owner",
					bg ='blue', command = logino)
button4.place(x = 50, y = 440, width = 85)
button5 = tk.Button(root, text ="Manager",
					bg ='blue', command = loginm)
button5.place(x = 50, y = 470, width = 85)
root.mainloop()


