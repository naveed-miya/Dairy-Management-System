from tkinter import *
import tkinter as tk
from tkinter import Label




# Create object
root = tk.Tk()

# Adjust size
root.geometry( "200x200" )
  
def display():
    #dummy
    x="dummy"

# Change the label text
def supp():
    display("supplier")
def disp():
    display("products_supplier")
def cust():
    display("customer")
def dis():
    display("distributor")
def ord():
    display("orders")
def cus():
    display("customer_order")
  
root.geometry("500x300")

label = Label( root , text = "Supplier Dashboard" )
label.pack()

button1 = tk.Button(root, text ="distributor",
					bg ='blue', command = dis)
button1.place(x = 35, y = 120, width = 80)

button2 = tk.Button(root, text ="Supplier",
					bg ='blue', command = supp)
button2.place(x = 115, y = 120, width = 75)

button3 = tk.Button(root, text ="Customer",
					bg ='blue', command = cust)
button3.place(x = 190, y = 120, width = 80)

button4 = tk.Button(root, text ="Products Supplier",
					bg ='blue', command = disp)
button4.place(x = 270, y = 120, width = 150)
# Create Label
button5 = tk.Button(root, text ="Exit",
					bg ='blue', command =root.destroy)
button5.place(x = 150, y = 250, width = 55)

button6 = tk.Button(root, text ="Orders",
					bg ='blue', command = ord)
button6.place(x = 120, y = 150, width = 80)

button7 = tk.Button(root, text ="Customer Orders",
					bg ='blue', command = cus)
button7.place(x = 200, y = 150, width = 130)
  
# Execute tkinter
root.mainloop()