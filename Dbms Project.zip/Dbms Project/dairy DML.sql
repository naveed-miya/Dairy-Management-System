
insert into farmowner values ('1', 'RK', '2122 stella st', '9347701958');
insert into farmowner values ('2', 'Teja', '2150 stella st', '8654423472');
insert into farmowner values ('3', 'Vishnu', '2122 texas', '9823645239');
insert into farmowner values ('4', 'Ram', '1922 wd', '9116367134');
insert into farmowner values ('5', 'Dev', '1999 wd', '9347575759');

insert into manager values('20', 'Raja', 'rajaE20@gmail.com', '8639408854');
insert into manager values('22', 'Ravi', 'raviT@gmail.com', '7269584256');
insert into manager values('5', 'Krishna', 'krishnaR@gmail.com', '9849632154');
insert into manager values('13', 'Gopal', 'Gopalrao@gmail.com', '7654562819');
insert into manager values('19', 'satish', 'satish19@gmail.com', '9243658291');

insert into fowner_manager values('4','5');
insert into fowner_manager values('3','13');
insert into fowner_manager values('1','19');
insert into fowner_manager values('5','20');
insert into fowner_manager values('2','22');

insert into distributor values('103' , 'Sunil', '19', '84', 'sunil19@gmail.com', '28');
insert into distributor values('104' , 'Naresh', '22', '88', 'naresh22@gmail.com', '30');
insert into distributor values('105' , 'Srinu', '13', '89', 'srinu13@gmail.com', '42');
insert into distributor values('106' , 'Madhu', '5', '83', 'madhu5@gmail.com', '53');
insert into distributor values('107' , 'srihari', '20', '86', 'sihari20@gmail.com', '16');

insert into milk_production values('1002','12','120');
insert into milk_production values('1006','16','122');
insert into milk_production values('1008','18','126');
insert into milk_production values('1010','20','129');
insert into milk_production values('1012','22','132');

insert into manager_production values('1008','18','22');
insert into manager_production values('1010','20','5');
insert into manager_production values('1006','16','13');
insert into manager_production values('1012','22','20');
insert into manager_production values('1002','12','19');

insert into financial_records values('50', 'profit', '2018');
insert into financial_records values('52', 'loss', '2019');
insert into financial_records values('56', 'loss', '2020');
insert into financial_records values('58', 'profit', '2021');
insert into financial_records values('60', 'profit', '2022');

insert into manager_financialrecords values('22','58');
insert into manager_financialrecords values('5','52');
insert into manager_financialrecords values('19','60');
insert into manager_financialrecords values('13','56');
insert into manager_financialrecords values('20','50');

insert into cattle values('126', '269','Buffalo');
insert into cattle values('132', '524','cow');
insert into cattle values('129', '638','goat');
insert into cattle values('122', '440','Murrah Buffalo');
insert into cattle values('120', '583','Jersey cow');

insert into farm_cattle values('4','126');
insert into farm_cattle values('1','122');
insert into farm_cattle values('3','120');
insert into farm_cattle values('2','132');
insert into farm_cattle values('5','129');

insert into categories values('92','Non pateurized','Buffalo','269');
insert into categories values('91','tetra packed','cow','524');
insert into categories values('98','pateurized','goat','638');
insert into categories values('96','pateurized','Murrah Buffalo','440');
insert into categories values('93','tetra packed','Jersey cow','583');

insert into cattle_categories values('126','92');
insert into cattle_categories values('132','91');
insert into cattle_categories values('129','98');
insert into cattle_categories values('122','96');
insert into cattle_categories values('120','93');

insert into fodder values('73','lucerne','34');
insert into fodder values('72','sorghum','68');
insert into fodder values('78','babul','52');
insert into fodder values('71','green fodder','23');
insert into fodder values('76','soyabean meal','70');

insert into cattle_fodder values('73','126');
insert into cattle_fodder values('72','132');
insert into cattle_fodder values('78','139');
insert into cattle_fodder values('71','122');
insert into cattle_fodder values('76','120');

insert into products values('B40','202','22 Jan','Hatsun','20','13 Mar','6');
insert into products values('C42','206','5 Mar','Heritage','40','12 Apr','8');
insert into products values('G46','208','13 Mar','Heritage','60','22 Apr','7');
insert into products values('MB48','204','20 Ju;','Amul','80','23 Aug','9');
insert into products values('JC44','203','19 May','Jersey','100','22 Jul','5');

insert into distributor_products values('103','B40');
insert into distributor_products values('104','C42');
insert into distributor_products values('105','G46');
insert into distributor_products values('106','MB48');
insert into distributor_products values('107','JC44');

insert into supplier values('84','sriram','202','32','9849404971');
insert into supplier values('88','sai','206','48','7654324863');
insert into supplier values('89','raju','208','63','9463238436');
insert into supplier values('83','gopi','204','68','7436324817');
insert into supplier values('86','ramu','203','32','8563238464');

insert into products_supplier values('B40','84');
insert into products_supplier values('C42','88');
insert into products_supplier values('G46','89');
insert into products_supplier values('MB48','83');
insert into products_supplier values('JC44','86');

insert into customer values('202','rani','219 fry street','7849404971');
insert into customer values('206','navya','627 bernard street','8794049417');
insert into customer values('208','bhavana','3100 stella street','9638497643');
insert into customer values('204','sita','2829 west hickory street','8883946752');
insert into customer values('203','rama','569 mark at denton','9438497625');

insert into orders values('219','2','56','3','1');
insert into orders values('216','3','84','2','4');
insert into orders values('214','4','112','4','3');
insert into orders values('212','12','336','5','5');
insert into orders values('213','6','168','1','2');

insert into customer_order values('204','219');
insert into customer_order values('208','216');
insert into customer_order values('203','214');
insert into customer_order values('206','212');
insert into customer_order values('202','213');























